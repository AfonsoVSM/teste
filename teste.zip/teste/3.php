<?php
	$nums = array();
	for ($i=0; $i <15 ; $i++){
		$nums[]=rand(1,1000);
	}

	foreach ($nums as $chave => $num) {
		if ($num%2==0){
			echo 'posicao: '.$chave.' numero: ' .$num. 'par';
		}
		else{
			echo 'posicao: '.$chave.' numero: ' .$num. 'impar';
		}
		echo '<br>';
		
	}
	?>