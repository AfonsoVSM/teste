<?php

$meses = array(
    1 => 'Janeiro',
      2 =>'Fevereiro',
      3 =>'Março',
     4 => 'Abril',
     5 => 'Maio',
     6 => 'Junho',
    7 =>  'Julho',
   8 =>   'Agosto',
    9 =>  'Setembro',
    10 =>  'Outubro',
    11 =>  'Novembro',
    12 =>  'Dezembro'
);
$diaSemana = array(
     1 => 'Domingo',
     2 => 'Segunda-Feira',
     3 => 'Terça-Feira',
     4 => 'Quarta-Feira',
     5 => 'Quinta-Feira',
     6 => 'Sexta-Feira',
     7 => 'Sábado'
);

echo "Mes ".$meses[$_POST['meses']];
echo "<br>";
echo "Dia ".$diaSemana[$_POST['dias']];
?>
