<?php

	$maior=-99999;
	$menor=99999;
	$soma=0;
	$produto=1;

	$nums = array();
	for ($i=0; $i <15 ; $i++){
		$nums[]=rand(1,10000);
	}

	foreach ($nums as $chave => $num) {
		if ($num>$maior){
			$maior=$num;
		}
		if ($num > $maior){
			$menor=$num;
		}
		$soma+=$num;
		$produto*=$num;
	}
	$media=$soma/15;

	echo "numero maior: " .$maior;
	echo "<br>";
	echo "numero menor: " .$menor;
	echo "media: ".$media;
	echo "<br>";
	echo "produto: ".$produto;
	?>